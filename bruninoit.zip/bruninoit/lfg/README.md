# lfg
Limit For Guest: limit number of topic that a guest can view and also (not yet) add a bbcode that display its content only to registered users
